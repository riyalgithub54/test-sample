<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('admin/login','Admin\Auth\LoginController@showLoginForm')->name('admin.login.get');
Route::post('admin/login','Admin\Auth\LoginController@login')->name('admin.login.post');

Route::group(['middleware'=>'admin'],function(){
	Route::get('/user/detail','UserController@index')->name('user.index');

	Route::get('/user/create','UserController@create')->name('user.create');
	Route::post('/user/store','UserController@store')->name('user.store');

	Route::get('/user/edit/{id}','UserController@edit')->name('user.edit');
	Route::post('/user/update','UserController@update')->name('user.update');

	Route::get('/user/delete/{id}','UserController@delete')->name('user.delete');

	Route::get('/server-side/datatable','Admin\ServerSideDataTableController@index')->name('serverside.datatable.get');

	Route::get('downloadExcel/{type}', 'Admin\MaatwebsiteDemoController@downloadExcel')->name('download.excel');
	Route::post('importExcel', 'Admin\MaatwebsiteDemoController@importExcel');

	Route::get('/admin/country/state/city','Admin\CountryStateCityController@getCountryStateCity')->name('country.state.city');
	Route::post('/admin/country/state/city','Admin\CountryStateCityController@store')->name('country.state.city.post');

	Route::get('admin/logout','Admin\Auth\LoginController@logout')->name('admin.logout');
});

//admin password reset routes
Route::post('admin/password/email','Admin\Auth\ForgotPasswordController@sendResetLinkEmail')->name('admin.password.email');
Route::get('admin/password/reset','Admin\Auth\ForgotPasswordController@showLinkRequestForm')->name('admin.password.request');
Route::post('admin/password/reset','Admin\Auth\ResetPasswordController@reset');
Route::get('admin/password/reset/{token}','Admin\Auth\ResetPasswordController@showResetForm')->name('admin.password.reset');

/* Create for Making Admin Theme Integration */
Route::get('/test-theme','TestThemeController@testTheme')->name('test.theme');
// Route::get('/admin/home','Admin\HomeController@index')->name('admin.dashboard');