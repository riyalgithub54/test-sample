<?php

Route::get('/emp/register','Employee\RegisterController@getRegister')->name('emp.register.get');
Route::post('/emp/register','Employee\RegisterController@postRegister')->name('emp.register.post');

Route::get('/emp/login','Employee\Auth\LoginController@showLoginForm')->name('emp.login.get');
Route::post('/emp/login','Employee\Auth\LoginController@login')->name('emp.login.post');

Route::group(['middleware'=>'emp'],function(){
	Route::get('/emp/home','Employee\HomeController@index')->name('emp.index');
	Route::get('emp/logout','Employee\Auth\LoginController@logout')->name('emp.logout');

	Route::get('/dynamic-form','Employee\DynamicFormController@getDynamicForm')->name('emp.dynamic.get');
	Route::post('/dynamic-form','Employee\DynamicFormController@postDynamicForm')->name('emp.dynamic.post');
});