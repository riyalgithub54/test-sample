<!DOCTYPE HTML>
<html>
<head>
<title>Employee Panel</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<!-- Bootstrap Core CSS -->
<link href="/backend/css/bootstrap.css" rel='stylesheet' type='text/css' />

<!-- Custom CSS -->
<link href="/backend/css/style.css" rel='stylesheet' type='text/css' />
<!-- font-awesome icons CSS-->
<link href="/backend/css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons CSS-->
 
 <!-- js-->
<script src="/backend/js/jquery-1.11.1.min.js"></script>
<script src="/backend/js/modernizr.custom.js"></script>

<!--webfonts-->
<link href="//fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
<!--//webfonts-->
 
<!-- Metis Menu -->
<script src="/backend/js/metisMenu.min.js"></script>
<script src="/backend/js/custom.js"></script>
<link href="/backend/css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
<style type="text/css">
    .alert {
        padding: 2.5px;
    }
</style>
</head> 
<body>
<div class="main-content">
        <!-- main content start-->
        <div id="page-wrapper">
            <div class="main-page signup-page">
                <h2 class="title1">Employee SignUp1</h2>
                <div class="sign-up-row widget-shadow">
                    <h5>Personal Information :</h5>
                <form action="<?php echo e(URL::route('emp.register.post')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="sign-u">
                        <input type="text" name="firstname" value="<?php echo e(old('firstname')); ?>" placeholder="First Name">
                        <?php if($errors->has('firstname')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('firstname')); ?></strong>
                            </span>
                        <?php endif; ?>
                        <div class="clearfix"> </div>
                    </div>
                    <div class="sign-u">
                                <input type="text" name="lastname" value="<?php echo e(old('lastname')); ?>" placeholder="Last Name">
                        <?php if($errors->has('lastname')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('lastname')); ?></strong>
                            </span>
                        <?php endif; ?>
                        <div class="clearfix"> </div>
                    </div>
                    <div class="sign-u">
                                <input type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email Address">
                        <?php if($errors->has('email')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                        <div class="clearfix"> </div>
                    </div>
                    <div class="sign-u">
                        <div class="sign-up1">
                            <h4>Gender* :</h4>
                        </div>
                        <div class="sign-up2">
                            <label>
                                <input type="radio" name="gender" value="male" checked="checked">
                                Male
                            </label>
                            <label>
                                <input type="radio" name="gender" value="female">
                                Female
                            </label>
                        </div>
                        <div class="clearfix"> </div>
                    </div>
                    <div class="sign-u">
                        <div class="sign-up1">
                            <h4>Profile Image* :</h4>
                        </div>
                        <div class="sign-up2">
                            <input type="file" name="profile_picture">
                        </div>
                        <div class="clearfix"> </div>
                        <?php if($errors->has('profile_picture')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('profile_picture')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <h6>Login Information :</h6>
                    <div class="sign-u">
                                <input type="password" name="password"  placeholder="Password">
                        <?php if($errors->has('password')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                        <div class="clearfix"> </div>
                    </div>
                    <div class="sign-u">
                                <input type="password" name="confirm_password" placeholder="Confirm Password">
                        <?php if($errors->has('confirm_password')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('confirm_password')); ?></strong>
                            </span>
                        <?php endif; ?>
                        </div>
                        <div class="clearfix"> </div>
                    <div class="sub_home">
                            <input type="submit" value="Submit">
                        <div class="clearfix"> </div>
                    </div>
                    <div class="registration">
                        Already Registered.
                        <a class="" href="<?php echo e(URL::route('emp.login.get')); ?>">
                            Login
                        </a>
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div>
    <!--scrolling js-->
    <script src="/backend/js/jquery.nicescroll.js"></script>
    <script src="/backend/js/scripts.js"></script>
    <!--//scrolling js-->
    
    <!-- Bootstrap Core JavaScript -->
   <script src="/backend/js/bootstrap.js"> </script>
    <!-- //Bootstrap Core JavaScript -->
</body>
</html>