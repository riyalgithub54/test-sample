<?php $__env->startSection('style'); ?>
    <style type="text/css">
    	select {
		    width: 100%;
		    height: 100%;
		}
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="row">
		<h3 class="title1">User Update</h3>
		<div class="form-three widget-shadow">
            
            <form method="POST" action="<?php echo e(route('user.update')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($edit_newuser['id']); ?>">
                <div class="form-group row">
                    <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                    <div class="col-md-6">
                        <input id="name" type="text" class="form-control" name="name" value="<?php echo e($edit_newuser['name']); ?>">

                        <?php if($errors->has('name')): ?>
                            <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

            	<div class="form-group row">
                    <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                    <div class="col-md-6">
                        <input id="email" type="email" class="form-control" name="email" value="<?php echo e($edit_newuser['email']); ?>">

                        <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

            	<div class="form-group row">
                    <label for="contact_no" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Contact No')); ?></label>

                    <div class="col-md-6">
                        <input id="contact_no" type="contact_no" class="form-control" name="contact_no" value="<?php echo e($edit_newuser['contact_no']); ?>">

                        <?php if($errors->has('contact_no')): ?>
                            <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('contact_no')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

            	<div class="form-group row">
                    <label for="Gender" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Gender')); ?></label>

                    <div class="col-md-6">
                        <input type="radio" name="gender" value="male" <?php if($edit_newuser['gender'] == "male"): ?> checked="checked" <?php endif; ?>>Male
                        <input type="radio" name="gender" value="female"  <?php if($edit_newuser['gender'] == "female"): ?> checked="checked" <?php endif; ?>>Female
                    </div>
                </div>

            	<div class="form-group row">
                    <label for="Department" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Department')); ?></label>

                    <div class="col-md-6">
                    	<select name="department"  class="form-control1">
                    		<option value="" style="display: none;">Select any department</option>
                    		<option value="development" <?php if($edit_newuser['department'] == "development"): ?> selected="selected" <?php endif; ?>>Development</option>
                    		<option value="architech" <?php if($edit_newuser['department'] == "architech"): ?> selected="selected" <?php endif; ?>>Architech</option>
                    		<option value="accountant" <?php if($edit_newuser['department'] == "accountant"): ?> selected="selected" <?php endif; ?>>Accountant</option>
                    	</select>
                    </div>
                </div>
                <div class="form-group row mb-0">
                    <div class="col-md-6 offset-md-4">
                        <button type="submit" class="btn btn-primary">
                            Update User
                        </button>
                    </div>
                </div>
            </form>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminlayout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>