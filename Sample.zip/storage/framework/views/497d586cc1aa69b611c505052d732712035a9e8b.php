<?php $__env->startSection('style'); ?>
    <style type="text/css">
    	select {
		    width: 100%;
		    height: 100%;
		}
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="row">
		<h3 class="title1">User Create</h3>
		<div class="form-three widget-shadow">
            <form method="POST" action="<?php echo e(URL::route('user.store')); ?>">
                <?php echo csrf_field(); ?>

                <div class="form-group row">
                    <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                    <div class="col-md-6">
                        <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">

                        <?php if($errors->has('name')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

            	<div class="form-group row">
                    <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                    <div class="col-md-6">
                        <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">

                        <?php if($errors->has('email')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

            	<div class="form-group row">
                    <label for="contact_no" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Contact No')); ?></label>

                    <div class="col-md-6">
                        <input id="contact_no" type="contact_no" class="form-control" name="contact_no" value="<?php echo e(old('contact_no')); ?>">

                        <?php if($errors->has('contact_no')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('contact_no')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

            	<div class="form-group row">
                    <label for="Gender" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Gender')); ?></label>

                    <div class="col-md-6">
                        <input type="radio" name="gender" value="male" checked="checked">Male
                        <input type="radio" name="gender" value="female">Female
                    </div>
                </div>

            	<div class="form-group row">
                    <label for="Department" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Department')); ?></label>

                    <div class="col-md-6">
                    	<select name="department"  class="form-control1">
                    		<option value="" style="display: none;">Select any department</option>
                    		<option value="development">Development</option>
                    		<option value="architech">Architech</option>
                    		<option value="accountant">Accountant</option>
                    	</select>

                        <?php if($errors->has('department')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('department')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group row mb-0" style="margin-top: 5%;">
                    <div class="col-md-6 offset-md-4">
                        <button type="submit" class="btn btn-primary">
                            Create User
                        </button>
                    </div>
                </div>
            </form>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminlayout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>