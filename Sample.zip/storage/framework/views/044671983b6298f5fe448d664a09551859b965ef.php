<?php $__env->startSection('content'); ?>
    <div class="main-page">
		<div class="row">
			<h3 class="title1">Ajax :- Country State City</h3>
			<div class="form-three widget-shadow">
				<form id="myForm" name="myForm" method="post">
					<?php echo csrf_field(); ?>
                	<div class="form-group row">
	                    <label for="country" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Select any Country')); ?></label>

	                    <div class="col-md-6">
	                    	<select name="country"  class="form-control1">
	                    		<option value="" style="display: none;">Select Any Country</option>
	                    		<?php $__currentLoopData = $country_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_country_key => $single_country_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                    			<option value="<?php echo e($single_country_key); ?>"><?php echo e($single_country_value); ?></option>
	                    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                    	</select>

	                        <?php if($errors->has('country')): ?>
	                            <span class="alert alert-danger">
	                                <strong><?php echo e($errors->first('country')); ?></strong>
	                            </span>
	                        <?php endif; ?>
	                    </div>
	                </div>
	                <div class="form-group row mb-0" style="margin-top: 5%;">
	                    <div class="col-md-6 offset-md-6">
	                        <button type="submit" class="btn btn-primary" id="submitForm">
	                            Create User
	                        </button>
	                    </div>
	                </div>
            	</form>
			</div>
		</div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
	<script type="text/javascript">
		var submitURL = "<?php echo e(URL::route('country.state.city.post')); ?>";
		// token = "<?php echo e(csrf_token()); ?>";

		$('#submitForm').click(function(){
			// $.ajax({
			// 	type:"POST",
	  //          	url:submitURL, 
	  //          	data        : { formData: "ss", token: token },
	  //           dataType    : 'json',
	  //          	success:function(res){
	  //          		console.log(res);
	  //          	}
	  //       });
		  	$.ajax({
			    type: 'POST',
			    url: submitURL,
			    contentType: 'application/json; charset=utf-8',
			    data: { formData: $('#myForm').serialize()},
			    dataType: 'json',
			    success:function(res){
	           		console.log(res);
	           	},
			    error:function(response){
	           		console.log(response);
	           	}
			});
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminlayout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>