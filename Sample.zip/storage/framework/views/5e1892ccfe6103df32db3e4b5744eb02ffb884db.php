<?php $__env->startSection('content'); ?>
    <div class="main-page">
		<h2>Welcome in Employee Panel</h2>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('employee.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>