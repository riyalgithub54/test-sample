<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="<?php echo e(URL::route('test.form.post')); ?>" method="post">
		<?php echo csrf_field(); ?>
		Name : <input type="text" name="name"><br><br>

		Email : <input type="email" name="email"><br><br>

		<input type="submit" name="btnsubmit" value="SUBMIT"/>
	</form>
</body>
</html>