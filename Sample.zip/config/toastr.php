<?php

return [
    'options' => ['positionClass'=>'toast-bottom-right','extendedTimeOut'=>"0",'tapToDismiss'=>'false','timeOut'=>'0','onclick'=>'null']
];