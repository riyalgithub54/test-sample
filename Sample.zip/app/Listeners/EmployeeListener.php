<?php

namespace App\Listeners;

use App\Events\EmployeeEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class EmployeeListener
{
    protected $emp_detail;
    public function __construct($emp_detail)
    {   
        dd("assaa");
        $this->emp_detail = $emp_detail;
    }

    public function handle(EmployeeEvent $event)
    {
    }
}
