<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Employee extends Authenticatable
{
    use Notifiable;
    
    protected $table = 'employees';

    protected $guard = 'employee';
    
    protected $fillable = ['id','firstname','lastname','email','gender','status','password','profile_picture'];
}
