<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TestThemeController extends Controller
{
    public function testTheme(){
    	return view('admin.home');
    }
}
