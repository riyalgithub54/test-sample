<?php

namespace App\Http\Controllers\Employee\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Auth;
class LoginController extends Controller
{
    use AuthenticatesUsers;

    protected $redirectTo = '/emp/home';
    protected $guard = 'employee';

    public function __construct()
    {
        $this->middleware('guest_emp')->except('logout');
    }

    public function showLoginForm()
    {
        return view('employee.login');
    }

    // protected function guard()
    // {
    //     return Auth::guard('employee');
    // }

    /* Login with extra parameter */
    public function login(Request $request)
    {
        $attempt = Auth::guard('employee')->attempt([
            'email' => $request->get('email'), 
            'password' => $request->get('password'), 
            'status' => '1'
        ]);
        
        if ($attempt) {
            return redirect()->intended('/emp/home');
        }else{
            return $this->sendFailedLoginResponse($request);
        }
    }

    public function logout(Request $request)
    {
        /* For All User Logout */
        // $this->guard()->logout();
        // $request->session()->invalidate();

        /* At a time one user logout */
        Auth::guard('employee')->logout();
        
        return redirect('/emp/login');
    }
}
