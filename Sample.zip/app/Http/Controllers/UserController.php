<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\UserRequest;
use App\UserNew;
use Auth,Toastr,Config,Session;
class UserController extends Controller
{
   	public function index(){
         // dd(Auth::guard('admin')->user()->name);
         $newuser_detail = UserNew::paginate(10);
         // $newuser_detail->withPath('/user/detail');
         return view('user.index',compact('newuser_detail'));
      }

    public function create(){
      return view('user.create');
    }

      public function store(UserRequest $request){
         $save_newuser = new UserNew;
         $save_newuser->fill($request->all());
         $save_newuser->gender = $request->gender;
         $save_newuser->save();

         /* for toastr message */
         $notification = array(
            'message' => 'Successful user stored', 
            'alert-type' => 'success'
         );

   		return redirect()->route('user.index')->with($notification);
   	}

   	public function edit($id){
   		$edit_newuser = UserNew::find($id);
   		return view('user.edit',compact('edit_newuser'));
   	}

   	public function delete($id){
   		$user_new = UserNew::find($id);
   		$user_new->delete();
   		
   		return redirect()->route('user.index');
   	}

   	public function update(UserRequest $request){

   		$update_newuser = UserNew::find($request['id']);
   		$update_newuser->fill($request->all());
   		$update_newuser->gender = $request->gender;
   		$update_newuser->save();
   		return redirect()->route('user.index');
   	}
}