<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Country;

class CountryStateCityController extends Controller
{
    public function getCountryStateCity(){
    	$country_list = Country::pluck('name','id');
    	// dd($country_list);
    	return view('admin.country_state_city',compact('country_list'));
    }

    public function store(Request $request){
    	echo "<pre>";
    	print_r($request->all());
    	exit();
    	// $input = request()->validate([
     //        'name' => 'required',
     //    ]);

        return response()->json(['success'=>'success','message'=>'done'],200);
    }
}