<!DOCTYPE HTML>
<html>
<head>
    @include('admin.adminlayout.head')
    @yield('style')
</head>
<body class="cbp-spmenu-push">
    <div class="main-content">
        @include('admin.adminlayout.content')
        <!-- main content start-->
        <div id="page-wrapper">
            @yield('content')
        </div>
        @include('admin.adminlayout.footer')
    </div>
        @include('admin.adminlayout.jslib')
        @yield('javascript')
</body>
</html>