@extends('admin.adminlayout.layout')

@section('content')
    <div class="main-page">
		<div class="row">
			<h3 class="title1">Ajax :- Country State City</h3>
			<div class="form-three widget-shadow">
				<form id="myForm" name="myForm" method="post">
					@csrf
                	<div class="form-group row">
	                    <label for="country" class="col-md-4 col-form-label text-md-right">{{ __('Select any Country') }}</label>

	                    <div class="col-md-6">
	                    	<select name="country"  class="form-control1">
	                    		<option value="" style="display: none;">Select Any Country</option>
	                    		@foreach($country_list as $single_country_key => $single_country_value)
	                    			<option value="{{$single_country_key}}">{{$single_country_value}}</option>
	                    		@endforeach
	                    	</select>

	                        @if ($errors->has('country'))
	                            <span class="alert alert-danger">
	                                <strong>{{ $errors->first('country') }}</strong>
	                            </span>
	                        @endif
	                    </div>
	                </div>
	                <div class="form-group row mb-0" style="margin-top: 5%;">
	                    <div class="col-md-6 offset-md-6">
	                        <button type="submit" class="btn btn-primary" id="submitForm">
	                            Create User
	                        </button>
	                    </div>
	                </div>
            	</form>
			</div>
		</div>
    </div>
@endsection

@section('javascript')
	<script type="text/javascript">
		var submitURL = "{{URL::route('country.state.city.post')}}";
		// token = "{{csrf_token()}}";

		$('#submitForm').click(function(){
			// $.ajax({
			// 	type:"POST",
	  //          	url:submitURL, 
	  //          	data        : { formData: "ss", token: token },
	  //           dataType    : 'json',
	  //          	success:function(res){
	  //          		console.log(res);
	  //          	}
	  //       });
		  	$.ajax({
			    type: 'POST',
			    url: submitURL,
			    contentType: 'application/json; charset=utf-8',
			    data: { formData: $('#myForm').serialize()},
			    dataType: 'json',
			    success:function(res){
	           		console.log(res);
	           	},
			    error:function(response){
	           		console.log(response);
	           	}
			});
		});
	</script>
@endsection