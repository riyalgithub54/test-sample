<div class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
	<!--left-fixed -navigation-->
	<aside class="sidebar-left">
	    <nav class="navbar navbar-inverse">
	        <div class="navbar-header">
	            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".collapse" aria-expanded="false">
		            <span class="sr-only">Toggle navigation</span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
	            </button>
            	<h1><a class="navbar-brand" href="index.html"><span class="fa fa-area-chart"></span> Stemmons<span class="dashboard_text">Boxer Property</span></a></h1>
	        </div>
	        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	            <ul class="sidebar-menu">
	              	<li class="header">MAIN NAVIGATION</li>
		            <li class="treeview">
		                <a href="{{URL::route('emp.index')}}">
		                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
		                </a>
		            </li>
		            <li class="treeview">
		                <a href="{{URL::route('emp.dynamic.get')}}">
		                <i class="fa fa-dashboard"></i> <span>Generate Dynamic Form</span>
		                </a>
		            </li>
				  	<li class="treeview">
		                <a href="#">
			                <i class="fa fa-laptop"></i>
			                	<span>Test Menu</span>
			                <i class="fa fa-angle-left pull-right"></i>
		                </a>
		                <ul class="treeview-menu">
		                  	<li><a href="#"><i class="fa fa-angle-right"></i> Menu 1</a></li>
		                  	<li><a href="#"><i class="fa fa-angle-right"></i> Menu 2</a></li>
		                </ul>
	              	</li>
	          	</ul>
          	</div>
          	<!-- /.navbar-collapse -->
	    </nav>
    </aside>
</div>
	<!--left-fixed -navigation-->
		
<!-- header-starts -->
<div class="sticky-header header-section ">
	<div class="header-left">
		<!--toggle button start-->
		<button id="showLeftPush"><i class="fa fa-bars"></i></button>
		<!--toggle button end-->
	</div>
	<div class="header-right">
		<div class="profile_details">		
			<ul>
				<li class="dropdown profile_details_drop">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
						<div class="profile_img">	
							<span class="prfil-img"><img src="/backend/images/2.jpg" alt=""> </span> 
							<div class="user-name">
								<p>{{Auth::guard('employee')->user()->firstname}}</p>
								<span>{{Auth::guard('employee')->user()->email}}</span>
							</div>
							<i class="fa fa-angle-down lnr"></i>
							<i class="fa fa-angle-up lnr"></i>
							<div class="clearfix"></div>	
						</div>	
					</a>
					<ul class="dropdown-menu drp-mnu">
						<li> <a href="#"><i class="fa fa-cog"></i> Settings</a> </li> 
						<li> <a href="#"><i class="fa fa-user"></i> My Account</a> </li> 
						<li> <a href="#"><i class="fa fa-suitcase"></i> Profile</a> </li> 
						<li> <a href="{{URL::route('emp.logout')}}"><i class="fa fa-sign-out"></i> Logout</a> </li>
					</ul>
				</li>
			</ul>
		</div>
		<div class="clearfix"> </div>				
	</div>
	<div class="clearfix"> </div>	
</div>
<!-- //header-ends -->
