<!DOCTYPE HTML>
<html>
<head>
    @include('employee.layouts.head')
    @yield('style')
</head>
<body class="cbp-spmenu-push">
    <div class="main-content">
        @include('employee.layouts.content')
        <!-- main content start-->
        <div id="page-wrapper">
            @yield('content')
        </div>
        @include('employee.layouts.footer')
    </div>
        @include('employee.layouts.jslib')
        @yield('javascript')
</body>
</html>