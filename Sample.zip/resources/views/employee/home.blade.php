@extends('employee.layouts.layout')

@section('content')
    <div class="main-page">
		<h2>Welcome in Employee Panel</h2>
    </div>
@endsection